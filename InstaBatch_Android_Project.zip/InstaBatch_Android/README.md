# InstaBatch Android starter

Kotlin + Jetpack Compose Android Studio project for your Flask/yt-dlp backend.

## Build
1. Deploy the Flask backend as a Render Web Service with HTTPS.
2. Add `SECRET_KEY`, `APP_PASSWORD` (optional), `FLASK_ENV=production`, `MAX_WORKERS=3`, `RATE_LIMIT=30`, and `CLEANUP_HOURS=24` as Render environment variables.
3. Replace `https://YOUR-RENDER-SERVICE.onrender.com` in `MainActivity.kt` with your actual service URL.
4. Open this folder in Android Studio and allow Gradle sync.
5. Build > Generate Signed Bundle / APK > APK. Create and securely retain a signing key.
6. Install the signed APK on your phone; share that same signed APK with friends.

## Phone requirements
No coding app is needed. Install only the final APK and use an internet connection.

## Before public release
This is a starter integration, not a tested production release. Your uploaded backend files did not include the `templates/` and `static/` directories needed by Flask. Confirm they exist in GitHub. Render's local filesystem may be ephemeral; use persistent disk/object storage for videos. The backend uses in-memory job state, which can be lost on restarts. Remote Render cannot access Chrome/Edge cookies from your phone. Instagram may block or change download access. Only download content you own or have permission to save.
